<?php
session_start();
if(!isset($_SESSION['login'])){
    header("Location: ../login.php");
    exit;
}
?>
<h1>Dashboard</h1>
<p>Login berhasil</p>
