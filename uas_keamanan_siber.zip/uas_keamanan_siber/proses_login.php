<?php
session_start();
include "config/db.php";

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

$q = mysqli_query($conn,"SELECT * FROM users WHERE username='$username'");
$user = mysqli_fetch_assoc($q);

if ($user && password_verify($password,$user['password'])){
    $_SESSION['login']=true;
    header("Location: dashboard/index.php");
    exit;
}else{
    header("Location: login.php?error=1");
    exit;
}
