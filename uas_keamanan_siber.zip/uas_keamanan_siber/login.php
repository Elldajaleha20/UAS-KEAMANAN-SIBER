<?php
session_start();
if (isset($_SESSION['login'])) {
    header("Location: dashboard/index.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Login</title></head>
<body>
<h2>Login</h2>
<?php if (isset($_GET['error'])) echo "<p style='color:red'>Login gagal</p>"; ?>
<form method="post" action="proses_login.php">
<input type="text" name="username" required><br><br>
<input type="password" name="password" required><br><br>
<button type="submit">Login</button>
</form>
</body>
</html>
